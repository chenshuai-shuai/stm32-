const app = getApp();
import mqtt from '../../utils/mqtt';

Page({
  data: {
    tempThreshold: 0,
    humidityThreshold: 0,
    waterTempThreshold: 0,
    client: null,
    sendairtemp: 0,
    sendairhum: 0,
    sendwatertemp: 0
  },
  /*----------输入回调------------*/
  onOpenSwitch: function () {
    const open = JSON.stringify({
      button: 1
    });
    this.data.client.publish('rj', open, function (err) {
      if (err) {
        console.log('阈值发送失败:', err);
      } else {
        
      }
    });
  },

  onCloseSwitch: function () {
    const close = JSON.stringify({
      button: 0
    });
    this.data.client.publish('rj', close, function (err) {
      if (err) {
        console.log('阈值发送失败:', err);
      } else {
        
      }
    });
  },
  // 空气温度输入回调
  onTempInput: function (e) {
    this.setData({
      sendairtemp: e.detail.value
    });
  },
  // 空气湿度输入回调
  onHumidityInput: function (e) {
    this.setData({
      sendairhum: e.detail.value
    });
  },

  // 水温输入回调
  onWaterTempInput: function (e) {
    this.setData({
      sendwatertemp: e.detail.value
    });
  },

  /*-----------按键回调------------------ */
  onConfirm: function () {
    wx.showToast({
      title: '阈值已更改',
      icon: 'success',
      duration: 1000
    });

    // 获取当前阈值
    const airTemp = this.data.sendairtemp;
    const airHumidity = this.data.sendairhum;
    const waterTemp = this.data.sendwatertemp;

    // 发送到 MQTT 主题
    const message = JSON.stringify({air_temp:airTemp,humidity:airHumidity,water_temp:waterTemp});

    if (this.data.client) {
      this.data.client.publish('rj', message, function (err) {
        if (err) {
          console.log('阈值发送失败:', err);
        } else {
          console.log('阈值发送成功:', message);
        }
      });
    }

  },
  onShow() {
    const that = this;
    that.setData({
      // websocket SSL
      client: mqtt('wxs://broker.emqx.io:8084/mqtt')
    });

    // MQTT 连接成功后事件
    that.data.client.on('connect', function () {
      console.log('成功连接到MQTT服务器');
      wx.showToast({
        title: '连接成功',
        icon: 'success',
        mask: 'true'
      })
      /* 连接成功之后订阅 */
      that.data.client.subscribe('/stm32_smartwash/pub', function (err) {
        if (!err) {
          console.log('成功订阅设备');
        }
      })
    });
    /* --------订阅消息处理------------ */
    that.data.client.on('message', function (topic, message) {
      console.log('接收到消息:', topic, message.toString());

      // 假设消息是一个JSON格式的字符串，解析出温度和湿度等数据
      try {
        const data = JSON.parse(message.toString());
        // 更新数据到界面
        that.setData({
          tempThreshold: data.airTemp,
          humidityThreshold: data.airHumidity,
          waterTempThreshold: data.waterTemp
        });

        console.log('空气温度:', that.data.tempThreshold);
        console.log('空气湿度:', that.data.humidityThreshold);
        console.log('水温:', that.data.waterTempThreshold);
      } catch (e) {
        console.log('解析消息失败:', e);
      }
    });
    // 处理连接错误
    that.data.client.on('error', function (err) {
      console.log('MQTT连接失败:', err);
    });
  }
});